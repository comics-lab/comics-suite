---
name: Feature request
about: Propose an improvement
labels: enhancement
---

**Problem**

**Proposal**

**Alternatives considered**

**Additional context**
