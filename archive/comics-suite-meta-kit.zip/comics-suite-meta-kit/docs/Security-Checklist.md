# Security Checklist — comics-suite (meta)

Date: 2025-10-19

- Org: 2FA, Security & Analysis, Actions lockdown, Teams, Apps/PATs, Audit log.
- Repos: Branch protection, Actions read-only token, Secret scanning, CodeQL default, Environments.
- Audits: 2FA compliance, coverage, rotate secrets, sample rules.
