#!/usr/bin/env bash
set -euo pipefail
ORG="comics-lab"
echo "Follow Security-Checklist.md for UI steps."
